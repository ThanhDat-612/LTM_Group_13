"""
Configuration loader for LTM Group 13.

Reads CODE/config.json and provides validated server settings.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


DEFAULT_CONFIG = {
    "server_host": "127.0.0.1",
    "server_port": 5000,
    "max_concurrent_uploads": 3,
    "chunk_size": 65536,
    "timeout_seconds": 30,
    "upload_dir": "uploads",
    "max_file_size_mb": 500,
}


class ConfigError(ValueError):
    """Raised when the server configuration is invalid."""


def _resolve_config_path(config_path: str | Path) -> Path:
    path = Path(config_path)

    if path.is_absolute():
        return path

    # config.json is located one directory above server/.
    candidates = [
        Path(__file__).resolve().parent.parent / path,
        Path.cwd() / path,
    ]

    for candidate in candidates:
        if candidate.exists():
            return candidate

    return candidates[0]


def validate_config(config: dict[str, Any]) -> dict[str, Any]:
    """Validate and normalize the project configuration."""
    result = DEFAULT_CONFIG.copy()
    result.update(config)

    host = result["server_host"]
    port = result["server_port"]
    max_uploads = result["max_concurrent_uploads"]
    chunk_size = result["chunk_size"]
    timeout = result["timeout_seconds"]
    upload_dir = result["upload_dir"]
    max_size = result["max_file_size_mb"]

    if not isinstance(host, str) or not host.strip():
        raise ConfigError("server_host must be a non-empty string.")

    for name, value in (
        ("server_port", port),
        ("max_concurrent_uploads", max_uploads),
        ("chunk_size", chunk_size),
        ("timeout_seconds", timeout),
        ("max_file_size_mb", max_size),
    ):
        if isinstance(value, bool) or not isinstance(value, int):
            raise ConfigError(f"{name} must be an integer.")

    if not 1 <= port <= 65535:
        raise ConfigError("server_port must be between 1 and 65535.")

    if max_uploads <= 0:
        raise ConfigError("max_concurrent_uploads must be greater than 0.")

    if chunk_size <= 0:
        raise ConfigError("chunk_size must be greater than 0.")

    if timeout <= 0:
        raise ConfigError("timeout_seconds must be greater than 0.")

    if max_size <= 0:
        raise ConfigError("max_file_size_mb must be greater than 0.")

    if not isinstance(upload_dir, str) or not upload_dir.strip():
        raise ConfigError("upload_dir must be a non-empty string.")

    return result


def load_config(config_path: str | Path = "config.json") -> dict[str, Any]:
    """Load and validate JSON configuration."""
    path = _resolve_config_path(config_path)

    if not path.exists():
        raise ConfigError(f"Configuration file not found: {path}")

    try:
        with open(path, "r", encoding="utf-8") as file:
            config = json.load(file)
    except json.JSONDecodeError as exc:
        raise ConfigError(f"Invalid JSON configuration: {exc}") from exc
    except OSError as exc:
        raise ConfigError(f"Cannot read configuration file: {exc}") from exc

    if not isinstance(config, dict):
        raise ConfigError("Configuration root must be a JSON object.")

    return validate_config(config)


class ConfigLoader:
    """Object-oriented wrapper used by server code."""

    def __init__(self, config_path: str | Path = "config.json"):
        self.path = _resolve_config_path(config_path)
        self.config = load_config(self.path)

    def get(self, key: str, default: Any = None) -> Any:
        return self.config.get(key, default)

    def __getitem__(self, key: str) -> Any:
        return self.config[key]
